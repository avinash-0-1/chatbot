import React, { createContext, useState } from 'react'
import main from './gemini'
export const Context = createContext()

const ContextProvider = (props) => {
    const [input, setInput] = useState('')
    const [recent_prmt, setRecent_prmt] = useState('')
    const [prev_prmt, setPrev_prmt] = useState([])
    const [show_result, setShow_result] = useState(false)
    const [loading, setLoading] = useState(false)
    const [result_data, setResult_data] = useState('')
    const [selectedFile, setSelectedFile] = useState(null)
    const [filePreviewUrl, setFilePreviewUrl] = useState(null) //*

    //=============[typing effect]==============
    const delayPara=(index,nextWord)=>{
        setTimeout(() => {
            setResult_data(prev=>prev+nextWord);
        },75*index);
    }

//======================= [Reset chat and clear file]================
    const newChat = ()=>{
        setLoading(true)
        setShow_result(false)
        setSelectedFile(null)
        if (filePreviewUrl) {
            URL.revokeObjectURL(filePreviewUrl)
        }
        setFilePreviewUrl(null)
    }

//====================== h msg api 
    const onSend = async(prmt)=>{
      setResult_data("")
      setLoading(true)
      setShow_result(true)
     //================================ # ================== 
      let response;
      if (prmt!==undefined){
        // Handle direct prompt #
        response = await main(prmt, selectedFile)  //pass file to api #
        setRecent_prmt(prmt)
      }
      else{
        // [Handle input field prompt] #
        setPrev_prmt(prev=>[...prev,input])
        setRecent_prmt(input)
        response = await main(input, selectedFile)  // pass file to api #
      }
      
      //[ Format response with bold text and line breaks]
      let responseArray = response.split("**")
      let newResponse='';
      for(let i=0;i<responseArray.length;i++){
            if(i==0||i%2 !==1){
                newResponse += responseArray[i];
            }
            else{
                newResponse += "<b>"+responseArray[i]+"</b>";
            }
      }
      let newResponse2 = newResponse.split("*").join("</br>") || newResponse.split("**").join("</br></br>")
      let newResponseArray = newResponse2.split(" ");
      
      //==================  {apply typing effect} ===============================================
      for(let i=0;i<newResponseArray.length;i++){
        const nextWord = newResponseArray[i];
        delayPara(i,nextWord+" ")
      }
      setLoading(false)
      setInput("")
    }

    // [handle file selection and remove] ================== #
    const handleFileChange = (file) => {
        if (file) {
            //[create preview url for the file]
            const previewUrl = URL.createObjectURL(file)
            setFilePreviewUrl(previewUrl)
            setSelectedFile(file)
            setInput('')
            setShow_result(false)  // hide prv response after file is set up #
        } else {
// ================================ clean up preview url when file is removed ===============
            if (filePreviewUrl) {
                URL.revokeObjectURL(filePreviewUrl)
            }
            setFilePreviewUrl(null)
            setSelectedFile(null)
            setInput('')
        }
    }

//================= [clean preview url] ===================== #
    React.useEffect(() => {
        return () => {
            if (filePreviewUrl) {
                URL.revokeObjectURL(filePreviewUrl)
            }
        }
    }, [filePreviewUrl])

    const contextValue = {
        prev_prmt,
        setPrev_prmt,
        onSend,
        recent_prmt,
        setRecent_prmt,
        show_result,
        loading,
        result_data,
        input,
        setInput,
        newChat,
        selectedFile,
        handleFileChange,
        filePreviewUrl    
    }

    return (
        <Context.Provider value={contextValue}>
            {props.children}
        </Context.Provider>
    )
}

export default ContextProvider